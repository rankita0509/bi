#Data classification(Practical No.03)

Hairfall<-c(12,13,14,17,15,18,12,13,14,17,19,18)
Hairfall
Hairfall.timeseries<-ts(Hairfall,start=c(2024,4),frequency=12)
Hairfall.timeseries
plot(Hairfall.timeseries)
 



#Data Clustering(Practical No.04)

newiris <- iris
newiris$Species <- NULL
(kc <- kmeans(newiris, 3))
	
table(iris$Species, kc$cluster)

plot(newiris[c("Sepal.Length", "Sepal.Width")], col = kc$cluster)
points(kc$centers[, c("Sepal.Length", "Sepal.Width")], col = 1:3, pch = 8, cex = 2)




#Linear regression on given data warehouse(Practical No.05)

X<-c(152,156,159,163,165)
Y<-c(63,68,59,71,64)
X
Y
relationYX<-lm(Y~X)
print(relationYX)

relationXY<-lm(X~Y)
print(relationXY)

summaryXY=summary(relationXY)
print(summaryXY)

summaryYX=summary(relationYX)
print(summaryYX)


a=data.frame(X=173)
result=predict(relationYX,a)
print(paste("Weight of the student when Height=173 is ",result," kg"))
 
b=data.frame(Y=70)
result1=predict(relationXY,b)
print(paste("Height of the student when weight=70 is ",result1," cm"))

plot(Y,X,col="blue",main="Height and Weight of Students",xlab="Weight",ylab="Height",pch=15,abline(lm(X~Y)))
 


#Logistic Regression on the given data warehouse(Practical No.06)

a=mtcars[c("cyl","wt","am","gear")]
d=head(a)
d
b<-glm(formula=am~cyl+wt,data=a,family=binomial)
c<- summary(b)
c


